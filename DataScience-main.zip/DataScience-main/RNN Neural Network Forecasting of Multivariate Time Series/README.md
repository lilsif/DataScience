Task description: https://voskresenskiianton.notion.site/Home-task-2-intern-data-scientist-Aramco-Inn-025d9726498d400aa3f27774739473b5
